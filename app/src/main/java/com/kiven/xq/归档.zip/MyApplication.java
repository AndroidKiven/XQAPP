package com.kiven.xq;

import android.app.Application;
import android.util.Log;

import com.mobile2345.ads.MobileAds;
import com.we.interfaces.LockCloseListener;
import com.we.interfaces.SdkInitListener;
import com.we.setting.AdSetting;
import com.we.setting.LiveSetting;

/**
 * Created by hepengcheng on 2018/7/18.
 */

public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        MobileAds.init(this.getApplicationContext(), new SdkInitListener() {
            @Override
            public void onFail() {

            }

            @Override
            public void onSuccess() {
                AdSetting.getInstance(MyApplication.this).setAdConfig("100046", "10004601,10004602,10004603");
                LiveSetting.getInstance(MyApplication.this).setLockCloseListener(new LockCloseListener() {
                    @Override
                    public void switchStateClosed() {
                        Log.e("MobAdsSdk", "锁屏被关闭");
                        LiveSetting.getInstance(MyApplication.this).setLockSwitchState(0, "123456789");
                    }
                });
            }
        });
    }
}
